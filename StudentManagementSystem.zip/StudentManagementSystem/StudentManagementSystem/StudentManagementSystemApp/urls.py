from django.urls import path

from StudentManagementSystemApp import views

urlpatterns=[
    path('',views.log_fun,name='log'),   # it will display login.html page
    path('logdata',views.logdata_fun),   #it wil read the data and verify user is super user

    path('reg',views.reg_fun,name='reg'),    # it will return to register.html page
    path('regdata',views.regdata_fun),   #it will create superuseer account

    path('home',views.home_fun,name='home'),  #it will redirect to home page
    path('add_students',views.addstudent_fun,name='add'),
    path('readdata',views.readdata_fun), #it will insert into student table

    path('display',views.display_fun,name='display'),  #it will display student data in display.html file
    path('update/<int:id>',views.update_fun,name='up'), #it will update student record
    path('delete/<int:id>',views.delete_fun,name='del'),#it will delete the student record
    path('log_out',views.log_out_fun,name='log_out')
]